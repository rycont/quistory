import styled from 'styled-components/native'
export default styled.Text`
font-size: 25px;
margin-top: 23px;
color: black;
margin-bottom: 3px;
`