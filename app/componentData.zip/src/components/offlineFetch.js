export const offlineFetch = (uri, option) => {
    return fetch(uri, option)
}