import React from 'react'
import { View } from 'react-native'
import styled from 'styled-components/native'

const Background = styled.ScrollView`
  background-color: #1e3546;
  padding: 18px;
`
const Title = styled.Text`
  color: white;
  font-size: 30px;
  font-weight: 700;
`
const OrangeBar = styled.View`
  background-color: #fec864;
  height: 2px;
  width: 75px;
  margin-top: 7.5px;
`
const Card = styled.View`
  background-color: white;
  border-radius: 12px;
  padding: 12px;
  margin-top: 20px;
  padding-bottom: 18px;
`
const CardTitle = styled.Text`
  color: black;
  opacity: 0.7;
  font-weight: 700;
  margin-bottom: 12px;
`
const Percentage = styled.Text`
  color: #ec9900;
  font-weight: 700;
  font-size: 30px;
  text-align: center;
`
const PercentageInfo = styled.Text`
  font-weight: 700;
  font-size: 14px;
  opacity: 0.5;
  text-align: center;
  padding-top: 3px;
`
const WrongProblem = styled.View`
  flex-direction: row;
`
const WrongProblemTitle = styled.Text`
  font-size: 16px;
  opacity: 0.8;
`
const WrongSelectionsContainer = styled.View`
  flex-direction: row;
  margin-top: 10px;
`
const Comment = styled.Text`
  font-size: 14px;
  color: black;
  margin-top: 12px;
`
const Selection = styled.Text`
  opacity: 0.6;
  font-size: 14px;
  border-right-color: rgba(0, 0, 0, 0.2);
  border-right-width: 1px;
  flex: 1;
  text-align: center;
`
const ProblemNumber = styled.Text`
  padding-right: 6px;
  font-size: 16px;
  opacity: 0.8;
`
const Contents = styled.View`
  flex: 1;
  border-bottom-color: rgba(0, 0, 0, 0.1);
  border-bottom-width: 2px;
  margin-bottom: 12px;
  padding-bottom: 12px;
`
const ImInput = styled.Text`
  border: 2px solid rgba(0, 0, 0, 0.2);
  border-radius: 12px;
  color: #00c850;
  font-size: 14px;
  padding: 3px 10px 3px 10px;
`
const UserInput = styled.Text`
  color: #ff0202;
  font-size: 14px;
  margin-left: 12px;
  margin-top: 3px;
`
const CorrectToo = styled.View`
  flex-direction: row;
  padding-left: 12px;
  padding-top: 6px;
`
const CorrectReconnition = styled.Text`
  font-size: 12px;
  opacity: 0.5;
`
const CorrectTooAnswers = styled.Text`
  opacity: 0.7;
  font-size: 12px;
  line-height: 16px;
  padding-left: 12px;
`
const OXSelection = styled(Selection)`
  font-size: 30px;
`
export default ({ result }) => {
  // const correctRate = (1 - result.map(quiz => Boolean(quiz?.isRight)).sort().indexOf(true)/result.length) * 100
  const corrects = result
    .map(quiz => Boolean(quiz.isRight))
    .sort()
    .indexOf(true)
  return (
    <Background>
      <Title>세션 결과</Title>
      <OrangeBar />
      <Card>
        <CardTitle>정답률</CardTitle>
        <Percentage>
          {Math.floor((1 - corrects / result.length) * 100)}%
        </Percentage>
        <PercentageInfo>{`맞춘 문제수: ${result.length - corrects}/${
          result.length
        }
  전체 평균보다 20%p 높습니다`}</PercentageInfo>
      </Card>
      <Card>
        <CardTitle>틀린 문제</CardTitle>
        {result
          .map((item, index) => item.isRight || { ...item, index })
          .filter(item => item !== true)
          .map(item => (
            <WrongProblem key={item.index}>
              {console.log('MAP 안에서 출력합니다!', item)}
              <ProblemNumber>{item.index + 1}.</ProblemNumber>
              <Contents>
                <WrongProblemTitle>{item.content}</WrongProblemTitle>

                {({
                  주관식: (
                    <>
                      <WrongSelectionsContainer>
                        <ImInput>{item.answer}</ImInput>
                        <UserInput>{item.userEntered}</UserInput>
                      </WrongSelectionsContainer>
                      <CorrectToo>
                        <CorrectReconnition>정답 인정</CorrectReconnition>
                        <CorrectTooAnswers>
                          {item.otherAnswer.join('\n')}
                        </CorrectTooAnswers>
                      </CorrectToo>
                      <Comment>
                        {item.comment}
                      </Comment>
                    </>
                  ),
                  '4지선다': <>
            <WrongSelectionsContainer>
              {item.selection.map((e, i) => <Selection style={{
                ...(e === item.answer ? {
                  color: '#FF0202',
                }: null),
                ...(e === item.userEntered ? {
                  color: '#00C850',
                }: null),
                ...(i === 3 ? {
                  borderRightWidth: 0
                }: null),
              }}>{e}</Selection>)}
            </WrongSelectionsContainer>
            <Comment>
              setState는 class형 component에서만 사용할 수 있습니다.
            </Comment>
                </>
                })[item.type]}
              </Contents>
            </WrongProblem>
          ))}
        <WrongProblem>
          <ProblemNumber>21.</ProblemNumber>
          <Contents>
            <WrongProblemTitle>React는 Google이 만들었다</WrongProblemTitle>
            <WrongSelectionsContainer>
              <OXSelection>O</OXSelection>
              <OXSelection
                style={{
                  color: '#00C850',
                  borderRightWidth: 0
                }}
              >
                X
              </OXSelection>
            </WrongSelectionsContainer>
            <Comment>
              React는 Facebook이 개발하였습니다. Google은 Angular와 Flutter를
              개발하였습니다.
            </Comment>
          </Contents>
        </WrongProblem>
        <WrongProblem>
          <ProblemNumber>7.</ProblemNumber>
          <Contents>
            <WrongProblemTitle>
              React의 Functional Component에서 사용할 수 없는 요소들로 옳은
              것은?
            </WrongProblemTitle>
            <WrongSelectionsContainer>
              <Selection>useState</Selection>
              <Selection
                style={{
                  color: '#00C850'
                }}
              >
                useState
              </Selection>
              <Selection>useState</Selection>
              <Selection
                style={{
                  color: '#FF0202',
                  borderRightWidth: 0
                }}
              >
                useState
              </Selection>
            </WrongSelectionsContainer>
            <Comment>
              setState는 class형 component에서만 사용할 수 있습니다.
            </Comment>
          </Contents>
        </WrongProblem>
        <WrongProblem>
          <ProblemNumber>15.</ProblemNumber>
          <Contents>
            <WrongProblemTitle>
              React의 Functional Component에서 사용할 수 없는 요소들로 옳은
              것은?
            </WrongProblemTitle>
            <WrongSelectionsContainer>
              <Selection>useState</Selection>
              <Selection
                style={{
                  color: '#00C850'
                }}
              >
                useState
              </Selection>
              <Selection>useState</Selection>
              <Selection
                style={{
                  color: '#FF0202',
                  borderRightWidth: 0
                }}
              >
                useState
              </Selection>
            </WrongSelectionsContainer>
            <Comment>
              React의 useState는 Functional 컴포넌트에서만 사용할 수 있습니다.
              이게 뭔 소리야!!
            </Comment>
          </Contents>
        </WrongProblem>
        <WrongProblem>
          <ProblemNumber>23.</ProblemNumber>
          <Contents>
            <WrongProblemTitle>
              최근 급부상하는 프론트엔드 프레임워크는?
            </WrongProblemTitle>
            <WrongSelectionsContainer>
              <ImInput>Svelte</ImInput>
              <UserInput>Vue</UserInput>
            </WrongSelectionsContainer>
            <CorrectToo>
              <CorrectReconnition>정답 인정</CorrectReconnition>
              <CorrectTooAnswers>
                {['마이크로 소프트', 'MS', 'microsoft'].join('\n')}
              </CorrectTooAnswers>
            </CorrectToo>
            <Comment>솔직히 Angular보다는 Svelte죠. 그쵸?</Comment>
          </Contents>
        </WrongProblem>
      </Card>
    </Background>
  )
}
