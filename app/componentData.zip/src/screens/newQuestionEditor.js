import React from 'react'
import { TouchableNativeFeedback, View, Alert } from 'react-native'
import styled from 'styled-components/native'
import Icon from 'react-native-vector-icons/MaterialIcons'
import { HeaderBackButton } from 'react-navigation'
import { Editor } from '../components/markdownEditor'
import { makeTopToast } from '../utils/makeToast'

let text

const QuestionEditor = () => {
    const FullscreenEditor = styled(Editor)`
    flex: 1;
    `
    return <FullscreenEditor onChangeText={_ => text = _} />
}
const addNewPost = () => {
    makeTopToast('질문이 등록되었습니다.')
}
QuestionEditor.navigationOptions = ({ navigation }) => ({
    headerRight: <View style={{ marginRight: 10 }}>
        <TouchableNativeFeedback onPress={() => {
            addNewPost()
            navigation.goBack()
        }}>
            <Icon name="done" size={24} color="white" />
        </TouchableNativeFeedback>
    </View>,
    headerLeft: <HeaderBackButton onPress={() => Alert.alert(undefined, '작성을 취소하시겠어요?', [
        {
            text: '아니요',
            style: 'cancel'
        },
        {
            text: '예',
            style: 'default',   
            onPress: () => navigation.goBack()
        }
    ])} tintColor="white"/>
})
export default QuestionEditor