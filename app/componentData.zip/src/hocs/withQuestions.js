import React from 'react'
function getQuestions() {

}

export default (Component) => {
    return ({navigation}) => <Component navigation={navigation} questions={[{
        examiner: '유헷',
        type: '주관식',
        content: '다음중 내가 오늘 먹은 반찬은?',
        comment: '맛탕은 맛있기 때문입니다. 맛탕은 특히 감자로 해도 되고 고구마로 해도 되고 호박도 맛있기 때문이에요.',
        answer: '맛탕',
        otherAnswer: ['고구마 맛탕', '고구마맛탕']
    }, {
        examiner: '유헷',
        type: 'OX',
        content: `홍경래의 난, 진주 농민 봉기, 임술 농민 봉기를 계기로 농민의 사회의식은 성장하였다.`,
        answer: false,
        comment: '해설은 이렇게 표시된다고 하네요?!',
    }, {
        examiner: '정한',
        type: '4지선다',
        answer: 2,
        selection: ['React', 'Vue', 'Svelte', 'Angular JS'],
        content: '다음 2019년 가장 급부상중인 프레임워크는?',
        comment: '그냥 그렇게 느껴집니다.'
    }]} />
}